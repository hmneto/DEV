﻿using RestApiModeloDDD.Domain.Entitys;

namespace RestApiModeloDDD.Domain.Core.Interfaces.Services
{
    public interface IServiceCliente : IServiceBase<Cliente>
    {
    }
}
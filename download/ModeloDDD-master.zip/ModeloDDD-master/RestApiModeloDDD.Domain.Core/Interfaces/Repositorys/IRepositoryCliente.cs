﻿using RestApiModeloDDD.Domain.Entitys;

namespace RestApiModeloDDD.Domain.Core.Interfaces.Repositorys
{
    public interface IRepositoryCliente : IRepositoryBase<Cliente>
    {
    }
}

﻿namespace RestApiModeloDDD.Domain.Entitys
{
    public class Base
    {
        public int Id { get; set; }
    }
}

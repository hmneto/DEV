﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Template.Auth.Models
{
    public static class Settings
    {
        public static string Secret = "Template123Template123"; //Precisa ter mais de 16 caracteres.
    }
}

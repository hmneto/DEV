# SensorReadDataApi v.10
Sensor API Rest -> C# .Net Core with Dapper And SQL Server

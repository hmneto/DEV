﻿namespace ServiceScope.Services
{
    public interface IService
    {
        string GetGuid();
    }
}

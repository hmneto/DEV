import React from 'react'
import { View, StyleSheet } from 'react-native'

import { NavigationContainer } from '@react-navigation/native'

import Tabs from './routes/Tabs'

export default () => (
  <View style={ Estilo.container }> 
  
    <NavigationContainer>

      <Tabs />

    </NavigationContainer>
  
  </View>
)

const Estilo = StyleSheet.create({
  container: {
    flexGrow: 1
  }
})
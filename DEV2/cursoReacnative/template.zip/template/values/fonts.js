export default {
  small: 12,
  base: 16,
  title: 28,
  buttonText: 18
}
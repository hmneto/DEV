import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

export default props => {

  return(
    <View> 
     
    </View>
  )
}

const Estilo = StyleSheet.create(
  {
    
  }
)
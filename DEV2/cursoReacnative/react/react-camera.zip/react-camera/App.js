import  React, {useState, useEffect}from 'react';
import { Text, View, StyleSheet, SafeAreaView } from 'react-native';
import {Camera} from 'expo-camera'

import Signature from 'react-native-signature-canvas'

export default function App() {

  const [type, setType] = useState(Camera.Constants.Type.back)
  const [hasPermission, setHasPermission ] = useState(null)

  useEffect(()=>{
    (async ()=>{
      const {status}=await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted')
    })()
  },[])

  // if(hasPermission === null){
  //   return <Text style={{fontSize:50}}>Acesso negado</Text>
  // }

  //   if(hasPermission === false){
  //   return <Text style={{fontSize:50}}>Acesso negado</Text>
  // }

      // <Camera 
      //   style={{flex:1}}
      //   type={type}
      // >
      // <View>

      // </View>
      // </Camera>



      
const Sign = ({ text, onOK }) => {
  const ref = useRef();

  // Called after ref.current.readSignature() reads a non-empty base64 string
  const handleOK = (signature) => {
    console.log(signature);
    onOK(signature); // Callback from Component props
  };

  // Called after ref.current.readSignature() reads an empty string
  const handleEmpty = () => {
    console.log("Empty");
  };

  // Called after ref.current.clearSignature()
  const handleClear = () => {
    console.log("clear success!");
  };

  // Called after end of stroke
  const handleEnd = () => {
    ref.current.readSignature();
  };

  // Called after ref.current.getData()
  const handleData = (data) => {
    console.log(data);
  };

  

  return (
    <SafeAreaView style={styles.constainer}>
         <Signature
          ref={ref}
          onEnd={handleEnd}
          onOK={handleOK}
          onEmpty={handleEmpty}
          onClear={handleClear}
          onGetData={handleData}
          autoClear={true}
          descriptionText={"text"}
    />
    </SafeAreaView>
  );
}}

const styles = StyleSheet.create({
  constainer:{
    flex:1,
    justifyContent:'center'
  },
  
});

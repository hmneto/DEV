import React from 'react';
import { View, Text, Image } from 'react-native';
import H1 from './components/comp';
import Estilo from './components/Estilo';

function App() {
  return (
    <View style={Estilo.container}>
      <Image style={Estilo.imagem} source={require('./assets/download.jpg')} />
      <Text style={Estilo.texto}>Olá Mundo. Começei bem</Text>
      <H1 texto="Eu sou o Avatar, TIO!"></H1>
    </View>
  );
}

export default App;

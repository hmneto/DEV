import React from 'react';
import { Text } from 'react-native';
import Estilo from './Estilo';

export default function (props) {
  // console.log(Object.keys(props));
  return (
    <Text
      style={[
        Estilo.texto
      ]}>
      {props.texto}
      {props.children}
    </Text>
  );
}

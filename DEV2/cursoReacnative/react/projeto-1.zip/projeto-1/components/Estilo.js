import { StyleSheet } from 'react-native';

const Estilo = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'blue'
  },
  texto: {
    color:'white',
    fontSize:20,
    marginBottom:20
  },
  imagem:{
    width:150,
    height: 150,
    borderRadius:100,
    marginBottom: 100
  }
});

export default Estilo;

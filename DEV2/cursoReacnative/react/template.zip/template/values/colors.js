export default {
  primary: '#3894c5',
  background: '#25367c',
  white: '#f1f1f1',
  dark: '#1f1f1f'
}
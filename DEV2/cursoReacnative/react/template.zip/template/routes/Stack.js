  import React from 'react'
  import { createNativeStackNavigator } from '@react-navigation/native-stack'

  import LoginScreen from '../screens/LoginScreen'
  import CadastroScreen from '../screens/CadastroScreen'
  import PerfilScreen from '../screens/PerfilScreen'
  import WebScreen from '../screens/WebScreen'

  const Stack = createNativeStackNavigator()


  export default props => {
    return (
      <Stack.Navigator>

      <Stack.Navigator>
    )
  }
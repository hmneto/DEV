import React from 'react';
import { Text, View, StyleSheet,Button } from 'react-native';
import Axios from 'axios'

function teste(aaa){
//console.log(aaa)

const api = Axios.create({
  baseURL: "https://localhost:44379",
});


api.get('/').then(x=>console.log(x))
}

export default function App() {
  return (
    <View style={styles.container}>
        <Button title="ok" onPress={()=>teste('ok')}></Button>
    </View>
  );
}

const styles = StyleSheet.create({
container:{
  padding:20
}
});

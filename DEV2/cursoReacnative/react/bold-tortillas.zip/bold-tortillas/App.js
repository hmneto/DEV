import React, {useState} from 'react';
import { View, Text, Button, Image, StyleSheet } from 'react-native';




export default () => {
  const [contador, setContador] = useState(0)

  return (
    <View style={Estilo.container}>

      <View style={Estilo.containerImg}>
        <Image
          source={require('./assets/logo-contador.png')}
          style={Estilo.img}
        />
      </View>
      <Text style={Estilo.text}>{contador}</Text>
      <Button title='+' color='#673ab7'
      onPress={()=>setContador(contador+1)}
       />
      <Button title='-' color='#673ab7'
       onPress={()=>{if(contador>0){setContador(contador-1)}}}/>
    </View>
  );
};

const Estilo = StyleSheet.create({
  img: {
    width: 100,
    height: 100,
  },
  container: {
    flexGrow: 1,
    backgroundColor: '#1F1F1F',
  },
  text: {
    fontSize: 80,
    textAlign: 'center',
    color: '#fff',
  },
  containerImg: {
    alignItems: 'center',
  },
});

import React from 'react'

import { NavigationContainer } from '@react-navigation/native'

import Stack from './routes/Stack'

export default () => (
  <NavigationContainer>
      <Stack />
  </NavigationContainer>
)
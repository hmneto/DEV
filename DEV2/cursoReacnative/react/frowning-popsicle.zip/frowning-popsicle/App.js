import * as React, {useState}from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {Camera} from 'expo-camera'


export default function App() {

  const [type, setType] = useState(Camera.Constants.Type.back)
  return (
    <View style={styles.container}>
      <Camera 
        style={{flex:1}}
        type={type}
      />
    </View>
  );
}

const styles = StyleSheet.create({
});

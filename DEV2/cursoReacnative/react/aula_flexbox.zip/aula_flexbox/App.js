import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

import ScreenFlexBox from './screens/FlexBox-2'

export default () => (
  <View style={ Estilo.container }> 
  
    <ScreenFlexBox />
  
  </View>
)

const Estilo = StyleSheet.create({
  container: {
    backgroundColor: '#ccc',
    flexGrow: 1,
    padding: 20,
    alignItems:'center'
  }
})
import React from 'react'
import { View, StyleSheet } from 'react-native'

import Quadrado from '../components/Quadrado'

export default props => {

  return(
    <View style={Estilo.containerScreen}>
      <View style={Estilo.vw1} />
      <View style={Estilo.vw2} />
    </View>
  )
}

const Estilo = StyleSheet.create({
  containerScreen:{
    flexGrow:1,
    backgroundColor:"#f1f1f1",
    width: 150
  },
  vw1:{
    backgroundColor:"#00A",
    flexGrow:1,
  },
    vw2:{
    backgroundColor:"#A00",
    flexGrow:1,
  }
})
import React from 'react'
import { View, StyleSheet } from 'react-native'

import Quadrado from '../components/Quadrado'

export default props => {

  return(
    <View style={Estilo.containerScreen}>
      <Quadrado cor="#A00" />
      <Quadrado cor="#0A0" />
      <Quadrado cor="#00A" />
      <Quadrado />
      <Quadrado />
      <Quadrado />
    </View>
  )
}

const Estilo = StyleSheet.create({
  containerScreen:{
    flexGrow:1,
    backgroundColor:"#f1f1f1",
    justifyContent: 'space-around',
    alignItems:'center',
    flexDirection: 'row',
    flexWrap: 'wrap'
  }
})
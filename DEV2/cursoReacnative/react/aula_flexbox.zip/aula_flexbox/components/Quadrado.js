import React from 'react'
import { View, StyleSheet } from 'react-native'

export default props => {

  // console.log(Object.keys(props))
  // console.log(props.cor)

  return(
    <View  
      style={ [ Estilo.quadrado, { backgroundColor: props.cor || '#1f1f1f'} ] } 
    />
  )
}

const Estilo = StyleSheet.create({
  quadrado: {
    height: 64,
    width: 64
  }
})
http://www.kodyaz.com/articles/delete-file-from-sql-server-xp-cmdshell-ole-automation-procedures.aspx


https://www.dirceuresende.com/blog/habilitando-ole-automation-via-t-sql-no-sql-server/
https://www.dirceuresende.com/blog/operacoes-com-arquivos-utilizando-ole-automation-no-sql-server/



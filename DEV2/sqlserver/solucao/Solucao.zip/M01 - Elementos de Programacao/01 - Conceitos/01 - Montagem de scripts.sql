/*
Script.

Arquivo texto com extens�o .SQL que cont�m um conjunto de 
instru��es em SQL ou T-SQL. Essas instru��es s�o para 
executar comandos de manuten��es,criar bancos, criar objetos 
de programa��o, monitoramento entre outros.

*/


/*
Onde usar scripts? 

- Nos seus projetos de banco de dados.
- Na cria��o de objetos de programa��o para sua aplica��o.
- Comandos para manuten��o de tabelas e banco de dados. 

*/

/*
Gerando scripts a partir do SQL Server Management Studio.

Backup 
Banco de Dados ( Gerar, trocar o nome do banco e criar)
Tabela ( Usar tabela tTMPMovimento) 
Procedure
Script Completo 
Script Completo + Avan�ado.


*/



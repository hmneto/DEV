

Select 'Este texto pode ser scrito \
em v�rias linhas dentro da instru��o \
SELECT, mas na execu��o ser� apresentado \
em apenas uma linha'

/*
Aten��o, n�o utilizar para construir comandos em v�rias linhas 
*/

select * from \
sys.objects 

select * from 
sys.objects 

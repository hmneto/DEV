/*
Variavel table n�o suporta SELECT INTO.
Evitar o uso at� mesmo para tempor�ria.

*/
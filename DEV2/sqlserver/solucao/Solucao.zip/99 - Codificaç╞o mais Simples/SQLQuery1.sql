https://www.mssqltips.com/sqlservertip/5792/write-more-compact-sql-server-code-using-new-features/
https://www.mssqltips.com/sqlservertip/5801/write-more-compact-sql-server-code-using-new-features--part-2/?utm_source=dailynewsletter&utm_medium=email&utm_content=headline&utm_campaign=20181203

